<?php

return array(

    'headerHeight' => 45,
    'widgetWidth'  => 340,
    'widgetHeight' => 400,
);