<?php

return array(

    'headerHeight' => 45,
    'widgetWidth'  => 337,
    'widgetHeight' => 411,
);