<?php

// Disable magic quotes

if(version_compare(PHP_VERSION, '5.3.0', '<'))
{
    try
    {
        @set_magic_quotes_runtime(0);
    }
    catch(Exception $e)
    {
        // Do nothing...
    }
}

?>
