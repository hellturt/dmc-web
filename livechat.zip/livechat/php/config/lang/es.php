<?php

return array(

    // Widget

    'loadingLabel'           => 'Cargando ...',
    'loginError'             => 'Error de inicio de sesión',
    'chatHeader'             => 'Chatea con Nosotros',
    'startInfo'              => 'Complete los siguientes campos para iniciar el chat',
    'selectDepartment'       => 'Elegir un departamento',
    'selectCancel'           => 'Cancelar',
    'startLabel'             => 'Iniciar',
    'backLabel'              => 'Regresar',
    'initMessageBody'        => 'Hola, ¿puedo ayudarte?',
    'initMessageAuthor'      => 'Operador',
    'chatInputLabel'         => 'Escribe tu pregunta aquí',
    'timeDaysAgo'            => 'Día (s) atrás',
    'timeHoursAgo'           => 'Hora (s) atrás ',
    'timeMinutesAgo'         => 'minutos (s) atrás',
    'timeSecondsAgo'         => 'segundo (s) atrás',
    'offlineMessage'         => 'El operador está fuera de línea',
    'toggleSoundLabel'       => 'Efectos de audio',
    'toggleScrollLabel'      => 'Desplazamiento automático',
    'toggleEmoticonsLabel'   => 'Emoticones',
    'toggleMediaLabel'       => 'Media',
    'toggleAutoShowLabel'    => 'Mostrar automáticamente',
    'toggleFullscreenLabel'  => 'Cambiar a pantalla completa',
    'endChatLabel'           => 'Fin del chat',
    'endChatConfirmQuestion' => '¿Estás seguro?',
    'endChatConfirm'         => 'Si',
    'endChatCancel'          => 'Cancelar',
    'mailTranscriptLabel'    => 'Enviar la transcripción por correo electrónico',
    'mailTranscriptHeader'   => 'Transferir conversación',
    'mailTranscriptInfo'     => 'Por favor, introduzca su dirección de correo electrónico para enviar la transcripción',
    'mailTranscriptSuccess'  => 'La transcripción ha sido enviada',
    'mailTranscriptError'    => 'Hubo un error al enviar la transcripción',
    'operatorClosedTalk'     => 'El operador ha cerrado la conversación',
    'loginAgain'             => 'Por favor inicie sesión de nuevo',
    'contactHeader'          => 'Contáctenos',
    'contactInfo'            => 'Todos los operadores están fuera de línea. Utilice el siguiente formulario para enviar su pregunta por correo electrónico. ',
    'contactNameLabel'       => 'Nombre',
    'contactMailLabel'       => 'Correo electrónico',
    'contactQuestionLabel'   => 'Su solicitud',
    'contactSendLabel'       => 'Enviar',
    'contactSuccessHeader'   => 'Mensaje enviado',
    'contactSuccessMessage'  => 'Gracias, su solicitud ha sido enviada',
    'contactErrorHeader'     => 'Error',
    'contactErrorMessage'    => 'Ocurrió un error de envío',
    'file.canceled'          => 'Eliminado',
    'file.error'             => 'Error',
    'file.denied'            => 'Denegado',
    'file.too.big'           => 'Tamaño máximo de carga:% max% MB',
    'you'                    => 'Tu',

    // Administration side

    'app.name' => 'Geckotech Live Chat',

    'login.title' => 'Login | Geckotech Live Chat',
    'login.intro' => 'Iniciar Sesión',
    'login.error' => 'Dirección de correo electrónico o contraseña incorrecta',
    'login' => 'Login',
    'your.mail' => 'Correo electrónico',
    'your.pass' => 'Contraseña',
    'your.msg' => 'Escribe tu mensaje',
    'online' => 'En línea',
    'offline' => 'Sin conexión',
    'welcome' => 'Bienvenido',
    'edit.profile' => 'Editar perfil',
    'edit.operator' => 'Cambiar operador',
    'add.new.msg' => 'Agregar nuevo mensaje',
    'add.new.operator' => 'Nuevo operador',
    'add.new.dep' => 'Nuevo departamento',
    'incorrect.install' => 'Instalación incorrecta',
    'please.install' => 'Instalar primero',
    'not.installed.msg' => 'La aplicación aún no está instalada, registrate como administrador e instalada antes de usarla',
    'install' => 'Instalar',
    'edit.config' => 'Cambiar configuración',
    'uninstall' => 'Desinstalar',
    'qr.code' => 'Código QR',
    'qr.code.info' => 'Desde la aplicación móvil escanea el código Qr para conectarse a este servidor',
    'qr.code.note' => "No escanee con una aplicación genérica para código Qr.    <br> Instale la aplicación PHP Live Chat para Android.",
    'logs' => 'Logs',
    'widget.preview' => 'Vista previa widget',
    'widget.get' => 'Obtener el script',
    'logout' => 'Cerrar Sesión',
    'chat.offline.info' => 'Cambie su estado a "En línea" para comenzar a chatear',
    'online.users' => 'Usuarios en línea',
    'online.operators' => 'Operadores en línea',
    'user.info' => 'Información del usuario',
    'visitor.invite' => 'Invitación del usuario',
    'invite.visitor.q' => '¿Quieres invitar al usuario a chatear?',
    'invite' => 'Invitar',
    'settings' => 'Configuración',
    'departments' => 'Departamentos',
    'operators' => 'Operadores',
    'widget.settings' => 'Configuraciones de widgets',
    'widget.theme' => 'tema del widget',
    'canned.messages' => 'Mensajes predeterminados',
    'widget.blacklist' => 'Widget blacklist',
    'history' => 'Historial',
    'primary.color' => 'Color primario',
    'secondary.color' => 'Color secundario',
    'label.color' => 'Color de la etiqueta',
    'contact.mail' => 'Formulario de contacto de correo electrónico',
    'hide.offline' => 'Ocultar cuando no está conectado',
    'show.widget.auto' => 'Mostrar el widget automáticamente',
    'every.refresh' => 'Actualizar en cada página',
    'first.visit' => 'Solo en la primera visita',
    'until.hide' => 'Hasta que el usuario oculte el widget',
    'allow' => 'Permitir',
    'turn.off' => 'Desactivar',
    'show.widget.after' => 'Mostrar el widget automáticamente después de (segundos)',
    'ask.mail' => 'Responder al usuario por correo',
    'media.in.chat' => 'Media en el chat (imágenes, video)',
    'display.auto' => 'Mostrar automáticamente',
    'display.clicked' => 'Mostrar cuando se hace clic',
    'chat.header' => 'Encabezado de chat',
    'welcome.msg' => 'Mensaje de bienvenida',
    'msg.sound' => 'Sonido mensaje nuevo',
    'sys.msg.sound' => 'Sonido Mensaje del Systema',
    'shared.max.size' => 'Tamaño máximo de carga (MB)',
    'file.sharing' => 'Compartir archivos',
    'gmaps.key' => 'Clave de la API de Google Maps',
    'widget.width' => "Ancho (en píxeles, mínimo 370)",
    'widget.height' => "Altura del widget (en píxeles)",
    'widget.side' => "Lado del widget",
    'left' => 'Left',
    'right' =>'Derecha',
    'widget.offset' => "Espacio en el costado del widget (en píxeles)",
    'mobile.bp' => 'Punto de interrupción para móvil',
    'operator.init.chat' => 'Conversaciones iniciadas por el operador',
    'online.track.int' => 'Tasas de actualización del seguimiento del usuario',
    'max.conn' => 'Conexiones máximas',
    'poll.interval' => 'Velocidad de actualización de chat',
    'save' => 'Guardar',
    'reset.to.def' => 'Restaurar valores predeterminados',
    'departments' => 'Departamentos',
    'add.new' => 'Agregar nuevo',
    'edit.department' => 'Editar departamento',
    'back.to.list' => 'Volver a la lista',
    'name' => 'Nombre',
    'description' => 'Descripción',
    'edit.op' =>  'Cambiar operador',
    'user.name' => 'Nombre de usuario',
    'mail' => 'E-mail',
    'user' => 'Usuario',
    'pass' => 'Contraseña',
    'retype.pass' => 'Repetir contraseña',
    'avatar' => 'Avatar',
    'from.coll' => 'De la biblioteca ...',
    'curr.pass' => 'contraseña actual',
    'new.pass' => 'Nueva contraseña',
    'retype.new.pass' => 'Volver a registrar una nueva contraseña',
    'change.pass' => 'Cambiar Contraseña',
    'cancel' => 'Cancelar',
    'insert' => 'Insertar',
    'send' => 'Enviar',
    'canned.msgs' => 'Mensaje predeterminado',
    'edit.msg' => 'Editar mensaje',
    'body' => 'Cuerpo',
    'placeholder.hint' => 'Puede usar <i>{name}</i> y <i>{mail}</i> placeholders',
    'pages.no.widget' => 'Páginas donde no se debe mostrar el widget:',
    'no.widget.hint' => '(define cada URL o parte de la línea URL, también puede usar expresiones regulares, por ej. <i>/test\.html$/</i>)',
    'search' => 'Buscar',
    'clear.history' => 'Eliminar historial',
    'clear.history.q' => '¿Seguro que quieres eliminar todos los mensajes?',
    'clear.messages' => 'Eliminar mensajes',
    'participants' => 'Participantes',
    'refresh' => 'Actualizar',
    'open.in.n.w' => 'Abrir en una nueva ventana',
    'clear' => 'Eliminar',
    'from.date' => 'De la fecha',
    'to.date' => 'A la fecha',
    'uninstall.title' => 'Desinstalar',
    'uninstall.success' => 'La aplicación se desinstaló correctamente y las tablas de la base de datos se eliminaron. La base de datos en sí misma, sin embargo, todavía existe (puede eliminarla manualmente si es necesario). ',
    'admin.panel' => 'Panel de administración',
    'uninstall.intro' =>"Esta es la página de desinstalación, si ya no desea utilizar esta aplicación, continúe
                haga clic en el botón <i>Desinstalar</i> .

                <br><br>

                La desinstalación significa que se eliminarán las cuentas del operador, el historial de mensajes y los mensajes predeterminados. La cuenta de administrador,
                sin embargo, seguirá estando disponible y podrá volver a iniciar sesión más tarde. Las tablas de la base de datos se eliminarán, pero la base de datos
                continuará existiendo (es posible que desee eliminarlo manualmente si es necesario).

                <br><br>

                <strong>
                    Una vez que se completa el proceso de desinstalación, se perderán todos los datos de la aplicación (cuenta del operador, historial de mensajes, mensajes predeterminados).
                    Si es necesario, antes de la instalación, puede hacer una copia de seguridad de las tablas de la base de datos de la aplicación utilizando la herramienta de administración de base de datos preferida, por ej. <i>phpMyAdmin</i>).
                </strong>",
    'uninstall.err' => 'Algo salió mal durante la desinstalación. El mensaje de error devuelto por la base de datos fue: ',
    'widget.test' => 'Prueba de widget',
    'install.title' => 'Configuración',
    'install.intro' => "Bienvenido a %app%. Antes de comenzar, la aplicación debe estar configurada
                que se ejecuta junto con su servidor de base de datos. Necesitará la siguiente información durante
                l instalación (si no conoce esos datos, puede obtenerlos de su empresa de alojamiento web):

                <br><br>

                1. Base de datos del host <br>
                2. Número de puerto de la base de datos (solo si no es el predeterminado)
                3. Nombre de la base de datos <br>
                4. Usuario de base de datos <br>
                5. Contraseña de base de datos

                <br><br>

                <strong>
                    Si la base de datos especificada aún no existe, el asistente de instalación intentará crearla automáticamente
                    para ti En algunos servidores, sin embargo, este intento fallará. No te preocupes, crea la base de datos
                    usando manualmente su herramienta de administración de base de datos preferida (por ejemplo, <i>phpMyAdmin</i>)  y vuelva a esta página
                    después de que haya terminado.
                </strong>",
    'lets.go' => "¡Vamos!",
    'wizard.2.title' => 'Instalación',
    'wizard.2.intro' => 'Compruebe si la configuración proporcionada es correcta y haga clic en <i>Instalar</i>.',
    'db.settings' => 'Configuración de la base de datos',
    'host' => 'Host',
    'port' => 'Port',
    'db.name' => 'Database name',
    'smtp' => 'SMTP',
    'use.smtp' => 'Usa SMTP',
    'encryption' => 'Crittografia',
    'hosts' => 'Host(s)',
    'hosts.i' => 'Host(s), separate with ;',
    'admin.acc.settings' => 'Impostazioni dell account aministratore',
    'other.settings' => 'Altre impostazioni',
    'back' => 'Indietro',
    'wizard.verify.intro' => 'Prima di procedere con l installazione, si prega di compilare il seguente modulo con il codice d acquisto. Puoi trovare il tuo codice d acquisto seuendo le istruizioni qui:',
    'verify.find.code' => 'Dov è il mio codice d acquisto',
    'verify.info' => 'Dati di installazione',
    'connection.error' => 'Errore di connessione',
    'invalid.code.format' => 'Codice di formato errato',
    'invalid.purchase' => 'Il codice non è valido o appartiene ad altri numeri',
    'install.not.verified' => 'Installazione non verificata',
    'purchase.code' => 'Codice d acquisto',
    'purchase.code.original' => 'Codice d acquisto (originale)',
    'purchase.code.upgrade' => 'Codice d acquisto (aggiornamento)',
    'wizard.3.title' => 'Installazione completata',
    'wizard.3.success' => 'L installazione è avvenuta con successo! Ora puoi seguire il pannello d amministrazione.',

    'wizard.intro' => "Le seguenti impostazioni sono la configurazione di base dell'intera applicazione.
    Sono usati per comunicare con il tuo database e definire l account dell'utente amministratore.
    Compila i moduli e continua facendo clic su <i>Salva</i>.

    <br><br>

    <strong>
        Se il database specificato non esiste ancora, il wizard di installazione proverà a crearlo automaticamente
        per te. Su alcuni server, tuttavia, questo tentativo fallirà. Non preoccuparti — crea il database
        manualmente usando il tuo strumento di amministrazione del database preferito (e.g. <i>phpMyAdmin</i>) e torna a questa pagina
        dopo che è finito.

        <br><br>

        Se hai già installato l'applicazione e desideri solo modificare alcune delle impostazioni, sentiti
        libero di aggiornare i valori e fai click su <i>Salva</i> (il database esistente rimarrà sicuro e intatto).
    </strong>",
    'wizard.input.err' => 'I tuoi dati di input sembrano non essere validi, controlla i messaggi di errore qui sotto e aggiorna il modulo.',
    'wizard.files.err' => 'L applicazione richiede che alcuni dei file siano scrivibili da PHP. Quanto segue non è attualmente scrivibile:',
    'wizard.files.err.2' => 'Si prega di aggiornare i permessi di file / directory rendendoli scrivibili e tornare dopo che è stato fatto.',
    'wizard.ext.err' => 'L applicazione richiede alcune estensioni PHP per essere disponibili. Le seguenti estensioni sono attualmente mancanti:',
    'wizard.ext.err.2' => "Si prega di abilitare le estensioni menzionate e tornare dopo averlo fatto
        <br>
        (se non sai come farlo, ti preghiamo di contattare la tua società di web hosting).",
    'wizard.err.db' => "L applicazione non ha potuto connettersi al database specificato.<br>
        Controlla due volte tutti i valori nella sezione <i>Impostazioni database</i> e assicurati che il tuo database sia in esecuzione.",
    'wizard.err.db.2' => "Tentativo di creare database e tabelle non riusciti.<br>
        Controlla due volte tutti i valori nella sezione <i>Impostazioni database</i>.

        <br><br>

        Se il tuo database — %dbName% — non esiste ancora, per favore crealo
        manualmente usando il tuo strumento di amministrazione del database preferito (e. g. <i>phpMyAdmin</i>) e torna quando è finito.

        <br><br>

        Il messaggio di errore interno era: %message%",
    'smtp.intro' => 'Questa sezione ti consente di utilizzare un server SMTP esterno per l invio di mail. Puoi lasciare invariate le impostazioni SMTP per utilizzare il server email predefinito.',
    'pass.repeat' => 'Ripeti Password',
    'value.blank' => 'Il valore è vuoto',
    'value.not.num' => 'Il valore non è un numero',
    'value.not.mail' => 'Value is not a valid e-mail',
    'value.too.short' => 'Il valore è troppo corto',
    'value.n.in.range' => 'Il valore è al di fuori dell intervallo consentito',
    'values.not.match' => 'I valori non corrispondono',
    'value.invalid' => 'Il valore non è valido',
    'db.invalid' => 'La struttura dei database non è valida',
    'db.exception' => 'Database exception: %msg%',
    'db.tables.invalid' => 'Struttura tabella non valida, tabelle effettive: %actual% expected tables: %expected%',
    'guest.watching' => 'El visitante está mirando',
    'unknown' => 'Desconocido',
    'invite.user' => 'Invitar usuario',
    'leave.talk' => 'Salir del chat',
    'canned' => 'Predeterminado',
    'confirm.install' => 'Confirmar para instalar la aplicación',
    'installation.invalid' => "Parece que la instalación no es válida.
                <br><br>
                es posible que los ajustes de configuración no sean correctos o que haya un problema con su base de datos.
                <br><br>
                Por favor, comprueba dos veces la configuración de la aplicación. ",
    'delete.user.q' => '¿Está seguro de que desea eliminar permanentemente este usuario?',
    'bottom.right.c' => 'esquina inferior derecha',
    'inline' => 'Inline',
    'no.entries' => 'Nada ingresado',
    'select.all' => 'Seleccionar todo',
    'select.none' => 'No seleccionar nada',
    'close.talk.msg' => "Usted es actualmente el propietario de esta conversación. Debe transferirla a otro chat.
                <br>
                 operador si necesita continuar, De lo contrario, debe cerrar el chat.
                <br><br>
                Seleccione el operador para abrir un chat: ",
    'talk' => 'Conversación',
    'user.alrdy.in.t' => 'El usuario está listo para hablar',
    'talk.not.exist' => 'La conversación no existe',
    'user.not.exist' => 'El usuario no existe',
    'cant.leave.unhandled.t' => "No se puede dejar un chat no administrado",
    'only.t.owner.can.close' => "Solo el propietario del chat puede cerrarlo",
    'only.t.owner.can.transfer' => "Solo el propietario de la conversación puede transferirlo",
    'curr.pass.incorrect' => 'Contraseña: la contraseña actual es incorrecta',
    'user.not.found' => 'Usuario no encontrado',
    'couldnt.save.user' => "No se puede guardar el usuario",
    'display.more' => 'Mostrar más',
    'id' => 'ID',
    'ip' => 'IP',
    'show.on.map' => 'Mostrar en el mapa',
    'map.no.api.key.info' => 'Ingrese su clave API de Google Maps en la pestaña "Configuración" y actualice la página.',
    'url' => 'URL',
    'browser' => 'Navegador',
    'system' => 'Sistema',
    'country' => 'País',
    'region' => 'Región',
    'city' => 'Ciudad',
    'zip.code' => 'Código postal',
    'time.zone' => 'Zona horaria',
    'local.time' => 'Hora local',
    'latitude' => 'Latitud',
    'longitude' => 'Longitud',
    'contact.form.mail' => 'Formulario de contacto de correo electrónico',
    'sent.from.page' => 'Enviado desde la página',
    'author.name' => "Nombre del autor",
    'author.mail' => "Correo electrónico del autor",
    'author.ip' => "IP del autor",
    'message' => 'Mensaje',
    'contact.mail.note' => 'Puede responder directamente a este correo electrónico para responder la pregunta',
    'talk.transcript.mail.title' => 'Transcripción de la Conversación',
    'talk.transcript.info' => 'Descargue el archivo adjunto, que contiene la transcripción de su discurso.',
    'talk.transcript.time' => 'Horario',
    'talk.transcript.filename' => 'Hablar-',
    'route.not.found' => 'Ruta no encontrada',
    'route.not.found.msg' => '<b>/%route%</b> ruta no encontrada.',
    'login.here' => 'Intenta iniciar sesión aquí',
    'error' => 'Error',
    'sth.went.wrong.msg' => "Parece que algo salió mal.
            <br><br>
            No obstante, no se preocupe: aquí está el mensaje de error que puede ayudarlo a encontrar el problema: ",

    'db.invalid.conn' => 'Intentando usar la base de datos con una conexión inválida.',
    'db.error' => 'Error de base de datos',
    'db.error.msg' => "La aplicación no se puede conectar a su base de datos. Asegúrese de que la configuración de la base de datos sea correcta.

                    <br><br>

                    <strong>
                        Si su base de datos — %dbName% — aún no existe, créelo
                        usando manualmente su herramienta de administración de base de datos preferida (por ejemplo, <i>phpMyAdmin</i>) y regrese cuando finalice.
                    </strong>

                    <br><br>

                    El mensaje de error devuelto por la base de datos fue: ",
    'sign.as.admin' => 'Inicie sesión como administrador y ajuste la configuración de su base de datos',
    'uninstall.error' => 'Ocurrió un error al desinstalar',
    'other.error' => 'Otro error',
    'admin.update.error' => 'Error al actualizar el usuario administrador',
    'error.saving.file' => 'Ocurrió un error al guardar el archivo',
    'form.error' => 'Error de formulario',
    'remove.msg' => 'Eliminar  "%message%"',
    'remove.msg.q' => '¿Seguro que quieres eliminar este mensaje?',
    'new.talk' => 'Nuova conversación',
    'cant.chat.w.self' => "No puedes chatear contigo mismo",
    'select.msg' => 'Seleccionar mensaje',
    'select.operator' => 'Seleccionar operador',
    'invitation' => 'Invitación',
    'leave.talk.q' => '¿Seguro que quieres dejar ésta conversación?',
    'leave.talk.confirm' => 'Sí, abandonar la conversación',
    'transfer.n.leave' => 'Transferir y salir',
    'end.talk' => 'Finalizar conversación',
    'transfer' => 'Transferir',
    'leave' => 'Dejar',
    'remove.dep' => 'Eliminar "%department%"',
    'remove.dep.q' => '¿Seguro que quieres eliminar este departamento?',
    'clear.history.err' => 'Error al borrar el historial',
    'history.cleared' => 'Historial de mensajes eliminados',
    'clear.logs' => 'Borrar registros',
    'clear.logs.q' => '¿Seguro que quieres eliminar todos los registros?',
    'logs.cleared' => 'Se borraron todos los registros',
    'clear.logs.err' => 'Error al eliminar registros',
    'widget.embd.code' => 'Código de inserción de widgets',
    'uploading' => 'Cargando',
    'uploading.image' => 'Cargando la imagen, espere ...',
    'avatar.uploaded' => 'Avatar subido',
    'uploaded.success' => 'Cargado con éxito',
    'remove.user' => 'Eliminar "%user%"',
    'remove.user.q' => '¿Seguro que quieres eliminar a tu usuario?',
    'select.avatar' => 'Selección de avatar',
    'reset.settings' => 'Restablecer configuraciones',
    'reset.settings.q' => '¿Seguro que quieres restablecer toda la configuración?',
    'reset' => 'Restablecer',
    'alert' => 'Alerta',
    'v.cant.be.empty' => 'El valor no puede estar vacío',
    'pass.have.to.match' => 'Las contraseñas deben coincidir',
    'enter.valid.mail' => 'Ingrese una dirección de correo electrónico válida',
    'pass.need.6.chars' => 'La contraseña debe tener al menos 6 caracteres',
    'close' => 'Cerrar',
    'language' => 'Idioma',
    'default.language' => 'Idioma predeterminado',
    'empty.mail.placeholder' => 'no@e.mail.provided',

    // System messages

    'sm.closed.talk' => '%user% ha cerrado la conversación',
    'sm.user.closed.chat' => 'El usuario ha cerrado el chat',
    'sm.now.talk.owner' => '%user% ahora es el propietario de ésta conversación',
    'sm.user.invited' => '%name% (%mail%) ha estado en la conversación',
    'sm.user.left' => '%name% (%mail%) ha salido de la conversación'
);

?>
