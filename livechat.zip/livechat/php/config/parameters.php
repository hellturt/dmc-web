<?php

return array (
  'dbHost' => '127.0.0.1',
  'dbPort' => '3306',
  'dbUser' => 'dotmecom_livechat_user',
  'dbPassword' => 'l1v3ch4t_us3r',
  'dbName' => 'dotmecom_livechat',
  'superUser' => 'admin',
  'superPass' => 'passw0rd',
  'services' => 
  array (
    'verify' => 
    array (
      'code' => 'e371c381-bb80-44e9-a8d2-1ec03d045a9c',
      'token' => 'fbe1f28193176bb25f377016763bb62daac7b78e',
    ),
    'mailer' => 
    array (
      'smtp' => '',
      'smtpSecure' => 'ssl',
      'smtpHost' => '',
      'smtpPort' => '465',
      'smtpUser' => '',
      'smtpPass' => '',
    ),
  ),
  'appSettings' => 
  array (
    'contactMail' => 'amri1616@gmail.com',
  ),
);

?>